export const routes = {
  home: "/home",
  profile: "/profile",
  about: "/about",
};
