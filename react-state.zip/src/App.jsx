import "./styles/index.css";
import "./styles/colors.css";
import "./styles/utilities.css";

import Home from "./pages/Home";
import Profile from "./pages/Profile";

import { BrowserRouter, Routes, Route } from "react-router-dom";
import { routes } from "./utils/routes";

const App = () => {
  return (
    <div className="flex column center">
      <BrowserRouter>
        <Routes>
          <Route path={routes.home} element={<Home />} />
          <Route path={routes.profile} element={<Profile />} />
          <Route path="/*" element={<h3>Not Found</h3>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
